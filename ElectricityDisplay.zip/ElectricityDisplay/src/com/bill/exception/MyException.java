package com.bill.exception;

public class MyException extends Exception{
private String msg;
	public MyException() {
}
public MyException(String msg)
{
	this.msg=msg;
}
public String toString()
{
	return msg;
}
}
