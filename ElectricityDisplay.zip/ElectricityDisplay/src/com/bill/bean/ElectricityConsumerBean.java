package com.bill.bean;

public class ElectricityConsumerBean {
private String consName;
private int consNumber;
private String address;
public String getConsName() {
	return consName;
}
public void setConsName(String consName) {
	this.consName = consName;
}
public int getConsNumber() {
	return consNumber;
}
public void setConsNumber(int consNumber) {
	this.consNumber = consNumber;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

}
